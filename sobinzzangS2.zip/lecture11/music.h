
#ifndef MUSIC_H
#define MUSIC_H

#define MUSIC_FILE_PATH1 "ost_shorts.wav"
#define MUSIC_FILE_PATH2 "click_sound.wav"
#endif